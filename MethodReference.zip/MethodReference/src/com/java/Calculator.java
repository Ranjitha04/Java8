package com.java;

public interface Calculator {

	int getResult(int num1, int num2);
}
