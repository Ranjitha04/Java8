package com.java;

public class VehicleImpl {

	Vehicle car = (name) -> System.out.println(name + " Car");
	
	Vehicle bus = System.out::print;
	
	
	public void display() {
		car.showName("Hundai");
		bus.showName("Volvo car");
	}
}
