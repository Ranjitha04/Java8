package com.java;

public interface Vehicle {

	public void showName(String name);
}
