package com.java;

public class MainClass {

	public static void main(String[] args) {

		/*
		 * VehicleImpl vehicle = new VehicleImpl(); vehicle.display();
		 */
		
		  //CalculationClass object = new CalculationClass();
		
		  Constructor construc = CalculationClass::new;
		  CalculationClass object = construc.getObject();
		  
		  //MR for non-static
		  Calculator calcFI1 =  object::addition;
		  int result = calcFI1.getResult(4, 5);
		  
		  System.out.println(result);
		  
		  
		  //MR for static
		  Calculator calcFI2 = CalculationClass::multiplication;   
		  int multiResult = calcFI2.getResult(8, 10);
		  System.out.println(multiResult);
		  
		  
	}

}
