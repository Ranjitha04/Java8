package com.java;

public interface Constructor {

	CalculationClass getObject();
}
