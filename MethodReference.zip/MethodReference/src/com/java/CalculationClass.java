package com.java;

public class CalculationClass {

	int addition(int num1, int num2) {
		return num1 + num2;
	}
	
	static int multiplication(int num1, int num2) {
		return num1 * num2;
	}
}
